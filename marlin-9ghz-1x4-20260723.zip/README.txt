# Fabrication Notes

- IPC spec: IPC6012F class 2
- Surface finish: Immersion tin
- Solder mask color: Blue
- Silk screen color: White
- For vias, use non-conductive epoxy filling with copper cap and planarization.
- Tented vias are marked in the Gerber files.
- There are no features on the bottom silk screen.
- Signal Layer 2 (G1) is COMPLETELY removed.
- Impedance control is necessary between Signal Layer 3 (G2) and Signal Layer 4 (GBL).  G2 is the reference.  Impedance control type: microstrip, target impedance: 50 Ohms, width: 0.52725 mm.